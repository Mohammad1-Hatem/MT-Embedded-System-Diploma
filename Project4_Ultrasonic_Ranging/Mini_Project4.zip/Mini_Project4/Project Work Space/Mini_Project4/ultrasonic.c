/*
 * ultrasonic.c
 *
 *  Created on: Oct 20, 2022
 *      Author: mohatem
 */

#include "ultrasonic.h"
#include "gpio.h"
#include "icu.h"
#include <util/delay.h> /* For the delay functions */

/* Declare three global variables */
static uint8 g_edgeCount = 0;
static uint16 g_timeHigh = 0;
static uint8 distance = 0;


static void ULTRA_edgeProcessing(void){
	g_edgeCount++;
	if(g_edgeCount == 1)
	{
		/*
		 * Clear the timer counter register to start measurements from the
		 * first detected rising edge
		 */
		Icu_clearTimerValue();
		/* Detect falling edge */
		Icu_setEdgeDetectionType(FALLING);

	}
	else if(g_edgeCount == 2)
	{
		/* Store the High time value */
		g_timeHigh = Icu_getInputCaptureValue();
		/* Detect rising edge */
		Icu_setEdgeDetectionType(RISING);
	}
}

/* Description:
 * Responsible for sending high input on trigger pin of the sensor
 */
static void Ultrasonic_Trigger(void){
	GPIO_writePin(TRIGGER_PORT,TRIGGER_PIN,LOGIC_HIGH);
	_delay_us(10);
	GPIO_writePin(TRIGGER_PORT,TRIGGER_PIN,LOGIC_LOW);
}

/* Description:
 *  Initialize the ultra-sonic sensor
 */
void Ultrasonic_init(void){

	/* Create configuration structure for ICU driver */
	Icu_ConfigType Icu_Config = {F_CPU_8,RISING};

	/* Setup the trigger pin as output */
	GPIO_setupPinDirection(TRIGGER_PORT,TRIGGER_PIN,PIN_OUTPUT);

	/* Initialize the ICU Driver */
	Icu_init(&Icu_Config);

	/* Set the Call back function pointer in the ICU driver */
	Icu_setCallBack(ULTRA_edgeProcessing);
}


uint16 Ultrasonic_readDistance(void){

	/* Clear the global variables */
	g_edgeCount = 0;
	g_timeHigh = 0;
	distance = 0;

	/* Clear the timer counter register to start measurements once trigger is sent */
	Icu_clearTimerValue();

	/* Responsible for sending high input on trigger pin of the sensor */
	Ultrasonic_Trigger();

	/* Wait until the ICU measures the pulse in the ECHO pin */
	while(g_edgeCount != Edges_Detected);

	distance = (g_timeHigh / 58) + 1;

	return distance;
}
