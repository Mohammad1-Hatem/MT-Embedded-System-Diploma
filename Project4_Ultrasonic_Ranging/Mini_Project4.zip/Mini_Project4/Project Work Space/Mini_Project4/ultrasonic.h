/*
 * ultrasonic.h
 *
 *  Created on: Oct 20, 2022
 *      Author: mohatem
 */

#ifndef ULTRASONIC_H_
#define ULTRASONIC_H_

#include "std_types.h"

/********************************************************
 * 							Definitions
 ********************************************************/

/* ULTRA-SONIC HW Ports and Pins IDs */
#define TRIGGER_PORT 				PORTB_ID
#define TRIGGER_PIN 				PIN5_ID

#define Edges_Detected			    	2
/*******************************************************************************
 *                      Functions Prototypes                                   *
 *******************************************************************************/

/* Description:
 * This function is responsible for convert the echo signal to ...
 * ... a specific number using ICU driver
 */
uint16 Ultrasonic_readDistance(void);

/* Description:
 *  Initialize the ultra-sonic sensor
 */
void Ultrasonic_init(void);

#endif /* ULTRASONIC_H_ */
