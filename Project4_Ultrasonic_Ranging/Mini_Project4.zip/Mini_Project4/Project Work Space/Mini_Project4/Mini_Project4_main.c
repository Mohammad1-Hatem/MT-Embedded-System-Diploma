/*
 * Mini_Project4
 * Project4_main.c
 *
 *  Created on: Oct 19, 2022
 *      Author: Mohammad Hatem
 *      Diploma: 72
 */

#include "ultrasonic.h"
#include "lcd.h"
#include "avr/io.h" /* To use the SREG Register */


int main(void){

	uint16 distance = 0;

	/* Enable Global Interrupt I-Bit */
	SREG |= (1<<7);

	/* Initialize both LCD and the Ultra-sonic drivers */
	LCD_init();
	Ultrasonic_init();


	/* Display the distance on LCD screen */
	LCD_displayStringRowColumn(0,0,"Distance =    cm");

	for(;;){

		distance = Ultrasonic_readDistance();

		LCD_moveCursor(0, 11);
		if(distance >= 100 && distance <= 500){
			LCD_intgerToString(distance);
		}
		else if(distance >= 10 && distance < 100){
			LCD_intgerToString(distance);
			LCD_displayCharacter(' ');
		}
		else if(distance < 10 && distance >= 3){
			LCD_intgerToString(distance);
			LCD_displayString("  ");
		}

	}
}
