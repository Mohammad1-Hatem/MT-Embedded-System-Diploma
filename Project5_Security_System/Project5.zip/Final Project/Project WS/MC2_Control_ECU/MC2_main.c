/*
 *     ---> Final Project "Updated" <---
 *
 *  Created on: Nov 4, 2022
 *      Author: Mohammad Hatem
 *      Diploma: 72
 */

#include "micro_config.h"
#include "UART.h"
#include "uart_communication.h"
#include "timer.h"
#include "Control_ECU_Functions.h"
#include "I2C.h"
#include "DC_MOTOR.h"
#include "buzzer.h"

/* Main */
int main(void){

	/* Enable Global Interrupt */
	SREG |= (1<<7);

	/* TWI Structure for its configurations */
	TWI_ConfigType TWI_Configurations;
	TWI_Configurations.Address = First;
	TWI_Configurations.BitRate = FAST_MODE_400KB ;
	TWI_Configurations.InterruptMode = INTERRUPT_MODE_ENABLE ;

	/* UART Structure for its configurations */
	UART_ConfigType uart_Struct;
	uart_Struct.baud_rate			= 9600;
	uart_Struct.InterruptMode		= POLLING;
	uart_Struct.parity			    = no_parity;
	uart_Struct.stop_bit			= STOP_BIT_1_BIT;

	/* Timer Structure for timer 1 configurations */
	/* Configure Timer1 to count for 1 Second*/
	Timer_ConfigType timer1_Strut;
	timer1_Strut.mode				= CTC_MODE_CHANNEL_A;
	timer1_Strut.compare_output		= NORMAL;
	timer1_Strut.OutputPin			= NONE;
	timer1_Strut.clock				= F_CPU_1024;
	timer1_Strut.initial			= 0;
	timer1_Strut.compare_value		= 7300;

	/* UART Initialization */
	UART_init(&uart_Struct);

	//Buzzer_init();
	Buzzer_init();

	/* TWI Initialization */
	TWI_init(&TWI_Configurations);

	/* Timer 1 Initialization */
	TIMER1_init(&timer1_Strut);

	/* CallBack Function for timer 1 CTC Channel A Interrupt Function */
	Timer1_setCallBack(Timer1_INT);

	/* DC Motor Initialization */
	DcMotor_Init();

	for(;;){

		/*
		 * Description :
		 * Ask the user for the password and confirmation ...
		 * and if matched store it automatically at EEPROM.
		 */
		Start_APP();

		/*
		 * Description :
		 * It's responsible for the main options (open door - change password).
		 */
		Main_APP();
	}
}
