/*
 * uart_communication.h
 *
 *  Created on: Nov 3, 2022
 *      Author: mohatem
 */

#ifndef UART_COMMUNICATION_H_
#define UART_COMMUNICATION_H_

#define MATCHED_PASSWORDS 							0x01
#define UNMATCHED_PASSWORDS							0x00

#define OPEN_DOOR  									0x04
#define LOCK_DOOR                                   0x08
#define CORRECT_PASSWORD 							0x03
#define  ERROR_PASS                                 0x10

#define CHECK_PASSWORD								0x05
#define MC1_READY 									0x06
#define PASSWORD_WRONG_3_TIMES						 3

#define  RESTART                                    0x09


#define  CREAT_PASS_AGAIN                            1


#define  CHANGE_PASS                                 2

#define  Control_ECU_READY                          0X02


#endif /* UART_COMMUNICATION_H_ */
