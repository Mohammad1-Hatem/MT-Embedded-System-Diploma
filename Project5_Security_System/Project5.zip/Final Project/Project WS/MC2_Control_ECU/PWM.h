/*
 * PWM.h
 *
 *  Created on: Oct 11, 2022
 *      Author: mohatem
 */

#ifndef PWM_H_
#define PWM_H_

#include "std_types.h"

/*******************************************************************************
 *                         Types Declaration                                   *
 *******************************************************************************/

/* Description:
 * Declare the modes of the duty cycle (0 - 25 - 50 - 75 - 100)%
 * */
typedef enum{
	No_duty = 0, Quarter_duty_cycle = 25, Half_duty_cycle = 50, Three_Quarters_duty_cycle = 75
	, Full_duty_cycle = 100
}duty_cycle;

/******************************************************************************************
 *                                  Functions Prototypes
 ******************************************************************************************/

/*
 * Description:
 * Generate a PWM signal with frequency 500Hz
 * Timer0 will be used with pre-scaler F_CPU/8
 * F_PWM=(F_CPU)/(256*N) = (10^6)/(256*8) = 500Hz
 * Duty Cycle can be changed by updating the value
 * in The Compare Register
 */
void PWM_Timer0_Start(uint8 duty_cycle);

#endif /* PWM_H_ */
