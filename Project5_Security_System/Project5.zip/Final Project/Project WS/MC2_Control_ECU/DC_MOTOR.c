/*
 * DC_MOTOR.c
 *
 *  Created on: Oct 11, 2022
 *      Author: mohatem
 */
#include <util/delay.h> /* For the delay functions */
#include "common_macros.h" /* For GET_BIT Macro */
#include "DC_MOTOR.h"
#include "PWM.h"
#include "gpio.h"

/*******************************************************************************
 *                      Functions Definitions                                  *
 *******************************************************************************/

/*
 * Description :
 * Function responsible for initialize the DcMotor driver.
 */
void DcMotor_Init(void){

	GPIO_setupPinDirection(INPUT1_PORT_ID,INPUT1_PIN_ID,PIN_OUTPUT);
	GPIO_setupPinDirection(INPUT2_PORT_ID,INPUT2_PIN_ID,PIN_OUTPUT);

	GPIO_writePin(INPUT1_PORT_ID,INPUT1_PIN_ID,LOGIC_LOW);
	GPIO_writePin(INPUT2_PORT_ID,INPUT2_PIN_ID,LOGIC_LOW);

}

/*
 * Description :
 * Function responsible for setting pins out to the H-Bridge,
 * and setting motor state (rotate CW/CCW - stop).
 */
void DcMotor_Rotate(DcMotor_State state,uint8 speed){

	switch(state){
	case rotate_CW:
		GPIO_writePin(INPUT1_PORT_ID,INPUT1_PIN_ID,LOGIC_HIGH);
		GPIO_writePin(INPUT2_PORT_ID,INPUT2_PIN_ID,LOGIC_LOW);

		PWM_Timer0_Start(speed);

		break;

	case rotate_CCW:
		GPIO_writePin(INPUT1_PORT_ID,INPUT1_PIN_ID,LOGIC_LOW);
		GPIO_writePin(INPUT2_PORT_ID,INPUT2_PIN_ID,LOGIC_HIGH);

		PWM_Timer0_Start(speed);

		break;

	case stop:
		GPIO_writePin(INPUT1_PORT_ID,INPUT1_PIN_ID,LOGIC_LOW);
		GPIO_writePin(INPUT2_PORT_ID,INPUT2_PIN_ID,LOGIC_LOW);

		PWM_Timer0_Start(0);
		break;
	}

}



