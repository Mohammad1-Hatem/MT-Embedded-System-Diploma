/*
 * Control_ECU_Functions.c
 *
 *  Created on: Nov 6, 2022
 *      Author: mohatem
 */

#include "Control_ECU_Functions.h"
#include <avr/io.h>
#include <util/delay.h>
#include "UART.h"
#include "UART_communication.h"
#include "I2C.h"
#include "external_eeprom.h"
#include "buzzer.h"
#include "DC_MOTOR.h"

/******************************************************************************
 *                                Global Variables
 ******************************************************************************/

/* the length of the password*/
#define PASS_LENGTH 5

uint8 first_pass[PASS_LENGTH], confirm_pass[PASS_LENGTH];
uint8 g_key, i, g_eeprom_pass[PASS_LENGTH];

uint8 trial_counter = 0, g_timer1_SecFlag = 0, choice;

/******************************************************************************
 *                                Functions Definitions
 ******************************************************************************/

/*
 * Description :
 * It's responsible for increasing the seconds counter each call.
 */
void Timer1_INT(){
	/* increment the timer counter every one second*/
	g_timer1_SecFlag++;
}

/*
 * Description :
 * Ask the user for the password and confirmation ...
 * and if matched store it automatically at EEPROM.
 */
void Start_APP(){

	Recieve_Pass(first_pass);
	Recieve_Pass(confirm_pass);

	UART_sendByte(Compare(first_pass,confirm_pass));

	if(Compare(first_pass,confirm_pass))
	{
		EEPROM_writeByte(0X3330, first_pass[0]);
		_delay_ms(10);
		EEPROM_writeByte(0X3331, first_pass[1]);
		_delay_ms(10);
		EEPROM_writeByte(0X3332, first_pass[2]);
		_delay_ms(10);
		EEPROM_writeByte(0X3333, first_pass[3]);
		_delay_ms(10);
		EEPROM_writeByte(0X3334, first_pass[4]);
		_delay_ms(10);
	}
	else{
		Start_APP();
	}

}


/*
 * Description :
 * It's responsible for the main options (open door - change password).
 */
void Main_APP(){

	/* Reading password which saved in EEPROM */
	EEPROM_readByte(0X3330, &g_eeprom_pass[0]);
	_delay_ms(10);
	EEPROM_readByte(0X3331, &g_eeprom_pass[1]);
	_delay_ms(10);
	EEPROM_readByte(0X3332, &g_eeprom_pass[2]);
	_delay_ms(10);
	EEPROM_readByte(0X3333, &g_eeprom_pass[3]);
	_delay_ms(10);
	EEPROM_readByte(0X3334, &g_eeprom_pass[4]);
	_delay_ms(10);

	Recieve_Pass(first_pass);

	if(Compare(first_pass,g_eeprom_pass))
	{
		UART_sendByte(MATCHED_PASSWORDS);

		while(UART_recieveByte()!=MC1_READY);

		choice = UART_recieveByte();

		if(choice == OPEN_DOOR)
		{
			Open_Door();
			Main_APP();
		}
		else if(choice == CHANGE_PASS)
		{
			Start_APP();
			Main_APP();
		}

	}
	else
	{
		UART_sendByte(UNMATCHED_PASSWORDS);

		trial_counter++;
		if(trial_counter<3)
		{
			Main_APP();
		}
		else if(trial_counter == PASSWORD_WRONG_3_TIMES)
		{
			trial_counter=0;
			Wrong_Pass_Error();
			Main_APP();

		}

	}
}

/*
 * Description :
 * It's responsible for opening the door via controlling the motor.
 */
void Open_Door(void)
{
	g_timer1_SecFlag = 0;


	DcMotor_Rotate(rotate_CW ,100);

	UART_sendByte(OPEN_DOOR);

	while(g_timer1_SecFlag <= 15);

	g_timer1_SecFlag = 0;

	DcMotor_Rotate(stop, 0);

	while(g_timer1_SecFlag <= 3);

	g_timer1_SecFlag = 0;

	UART_sendByte(LOCK_DOOR);
	DcMotor_Rotate(rotate_CCW ,100);

	while(g_timer1_SecFlag <= 15);

	DcMotor_Rotate(stop, 0);
	UART_sendByte(RESTART);
}

/*
 * Description :
 * It's responsible for initiating the buzzer if the user entered ...
 * wrong password for 3 times!
 */
void Wrong_Pass_Error(void)
{
	g_timer1_SecFlag=0;

	while(g_timer1_SecFlag<=60)
	{
		UART_sendByte(ERROR_PASS);
		Buzzer_on();
	}

	Buzzer_off();
	UART_sendByte(RESTART);
}

/*
 * Description :
 * It's responsible for comparing the two passwords arrays.
 */
uint8 Compare(uint8 array1[],uint8 array2[]){
	uint8 i;
	/* Check if the two arrays are matched or not */
	for (i = 0; i < 5; i++){
		if(array1[i] != array2[i]){
			/* if at least one element is not matched return 0 */
			return 0;
		}
	}
	/* if they are matched return 1 */
	return 1;
}

/*
 * Description :
 * It's responsible for sending password element by element.
 * The problem is that we tried to combine numbers and '#' in the same array.
 * The other solution is to send byte by byte without '#'.
 */
void Recieve_Pass(uint8 *pass_ptr){
	while(UART_recieveByte() != MC1_READY);
	pass_ptr[0] = UART_recieveByte();

	while(UART_recieveByte() != MC1_READY);
	pass_ptr[1] = UART_recieveByte();

	while(UART_recieveByte() != MC1_READY);
	pass_ptr[2] = UART_recieveByte();

	while(UART_recieveByte() != MC1_READY);
	pass_ptr[3] = UART_recieveByte();

	while(UART_recieveByte() != MC1_READY);
	pass_ptr[4] = UART_recieveByte();
}




