/*
 * Control_ECU_Functions.h
 *
 *  Created on: Nov 6, 2022
 *      Author: mohatem
 */

#ifndef CONTROL_ECU_FUNCTIONS_H_
#define CONTROL_ECU_FUNCTIONS_H_

#include "micro_config.h"
#include "UART.h"
#include "UART_communication.h"
#include "timer.h"

/************************************************************************
  	  	  	  	  	  	  	 Function Prototypes
 ***********************************************************************/

/*
 * Description :
 * It's responsible for increasing the seconds counter each call.
 */
void Timer1_INT(void);

/*
 * Description :
 * Ask the user for the password and confirmation ...
 * and if matched store it automatically at EEPROM.
 */
void Start_APP(void);

/*
 * Description :
 * It's responsible for the main options (open door - change password).
 */
void Main_APP(void);

/*
 * Description :
 * It's responsible for opening the door via controlling the motor.
 */
void Open_Door(void);

/*
 * Description :
 * It's responsible for initiating the buzzer if the user entered ...
 * wrong password for 3 times!
 */
void Wrong_Pass_Error(void);

/*
 * Description :
 * It's responsible for comparing the two passwords arrays.
 */
uint8 Compare(uint8 array1[],uint8 array2[]);

/*
 * Description :
 * It's responsible for sending password element by element.
 * The problem is that we tried to combine numbers and '#' in the same array.
 * The other solution is to send byte by byte without '#'.
 */
void Recieve_Pass(uint8 *pass_ptr);

#endif /* CONTROL_ECU_FUNCTIONS_H_ */
