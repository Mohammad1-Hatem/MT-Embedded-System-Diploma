/*
 *     ---> Final Project "Updated" <---
 *
 *  Created on: Nov 4, 2022
 *      Author: Mohammad Hatem
 *      Diploma: 72
 */

#include <avr/io.h>
#include <util/delay.h>
#include "LCD.h"
#include "keypad.h"
#include "UART_communication.h"
#include "HMI_Functions.h"
#include "UART.h"

/* Main */
int main(void){

	/* Enable Global Interrupt */
	SREG |= (1<<7);

	/* UART Structure for its configurations */
	UART_ConfigType uart_Struct;
	uart_Struct.baud_rate			= 9600;
	uart_Struct.InterruptMode		= POLLING;
	uart_Struct.parity			    = no_parity;
	uart_Struct.stop_bit			= STOP_BIT_1_BIT;

	/* UART Initialization */
	UART_init(&uart_Struct);

	LCD_init(); /* Initialize the LCD */

	/*Clear the LCD*/
	LCD_clearScreen();

	/*Display welcome message*/
	LCD_displayStringRowColumn(0,0,"Welcome :)");
	_delay_ms(500);


	for(;;){

		/*
		 * Description :
		 * Ask the user for the password and confirmation ...
		 * and if matched store it automatically at EEPROM.
		 */
		Start_APP();

		/*
		 * Description :
		 * It's responsible for the main options (open door - change password).
		 */
		Main_APP();
	}

}

