/*
 * HMI_Functions.c
 *
 *  Created on: Nov 6, 2022
 *      Author: mohatem
 */

#include "HMI_Functions.h"
#include <avr/io.h>
#include <util/delay.h>
#include "LCD.h"
#include "keypad.h"
#include "UART.h"
#include "UART_communication.h"

/******************************************************************************
 *                                Global Variables
 ******************************************************************************/

/* the length of the password*/
#define PASS_LENGTH 5

uint8 first_pass[PASS_LENGTH], confirm_pass[PASS_LENGTH];
uint8 g_key, i, trial_counter;

/******************************************************************************
 *                                Functions Definitions
 ******************************************************************************/

/*
 * Description :
 * Ask the user for the password and confirmation ...
 * and if matched store it automatically at EEPROM.
 */
void Start_APP(){

	/*Clear the LCD*/
	LCD_clearScreen();
	/* Start from first Pixel */
	LCD_displayStringRowColumn(0,0,"plz enter pass:");
	/* Start from second row - first Pixel */
	LCD_moveCursor(1,0);

	Enter_Pass(first_pass);

	/*Clear the LCD*/
	LCD_clearScreen();
	/* Start from first Pixel */
	LCD_moveCursor(0,0);
	LCD_displayString("plz re-enter the");
	/* Start from second row - first Pixel */
	LCD_moveCursor(1,0);
	LCD_displayString("same pass: ");
	LCD_moveCursor(1,11);

	Enter_Pass(confirm_pass);


	if(UART_recieveByte() == MATCHED_PASSWORDS){
		/*Clear the LCD*/
		LCD_clearScreen();
		/* Start from first Pixel */
		LCD_displayStringRowColumn(0,0,"matched");
		_delay_ms(500);

		LCD_displayStringRowColumn(0, 0, "+ : Open Door");
		LCD_displayStringRowColumn(1, 0, "- : Change pass");
		//_delay_ms(500);
		g_key = KEYPAD_getPressedKey();
	}
	else{
		/*Clear the LCD*/
		LCD_clearScreen();
		LCD_displayStringRowColumn(0,0,"unmatched");
		_delay_ms(500);

		Start_APP();
	}
}

/*
 * Description :
 * It's responsible for the main options (open door - change password).
 */
void Main_APP(){

	if(g_key == '+'){
		LCD_clearScreen();
		LCD_displayStringRowColumn(0, 0, "plz enter pass:");
		LCD_moveCursor(1,0);

		Enter_Pass(first_pass);

		if(UART_recieveByte() == MATCHED_PASSWORDS){
			Open_Door();
			Main_APP();
		}
		else{
			trial_counter++;
			if(trial_counter<3){
				g_key = '+';
				Main_APP();
			}
			else if(trial_counter == PASSWORD_WRONG_3_TIMES){
				trial_counter = 0;
				Wrong_Pass_Error();
				Main_APP();
			}
		}
	}
	else if(g_key == '-'){
		LCD_clearScreen();
		LCD_displayStringRowColumn(0, 0, "Plz enter pass:");
		LCD_moveCursor(1,0);

		Enter_Pass(first_pass);


		if(UART_recieveByte() == MATCHED_PASSWORDS)
		{
			UART_sendByte(MC1_READY);

			UART_sendByte(CHECK_PASSWORD);

			Start_APP();
			Main_APP();
		}
		else{
			trial_counter++;
			if(trial_counter<3)
			{
				g_key = '-';
				Main_APP();

			}
			else if(trial_counter==PASSWORD_WRONG_3_TIMES)
			{
				trial_counter=0;
				Wrong_Pass_Error();
				Main_APP();
			}

		}
	}
}

/*
 * Description :
 * It's responsible for opening the door via controlling the motor.
 */
void Open_Door(){
	UART_sendByte(MC1_READY);

	UART_sendByte(OPEN_DOOR);

	while(UART_recieveByte()!=OPEN_DOOR);

	LCD_clearScreen();
	LCD_displayString("DoorIs unlocking");

	while(UART_recieveByte()!=LOCK_DOOR);

	LCD_clearScreen();
	LCD_displayString("Door is locking");

	while(UART_recieveByte()!=RESTART);

	LCD_clearScreen();
	LCD_displayStringRowColumn(0, 0, "+ : Open Door");
	LCD_displayStringRowColumn(1, 0, "- : Change pass");
	g_key=KEYPAD_getPressedKey() ;
}

/*
 * Description :
 * It's responsible for initiating the buzzer if the user entered ...
 * wrong password for 3 times!
 */
void Wrong_Pass_Error(){
	while(UART_recieveByte()!=ERROR_PASS);
	LCD_clearScreen();
	LCD_displayString("xWrong Passwordx");
	while(UART_recieveByte() != RESTART);

	LCD_clearScreen();
	LCD_displayStringRowColumn(0, 0, "+ : Open Door");
	LCD_displayStringRowColumn(1, 0, "- : Change pass");
	g_key=KEYPAD_getPressedKey();
	_delay_ms(300);
}

/*
 * Description :
 * It's responsible for taking the passwords from the user element by element.
 */
void  Enter_Pass(uint8 *pass)
{
	uint8 counter = 0 , key = 0;

	for(counter=0;counter<5;counter++)
	{
		/* Time for press the button*/
		_delay_ms(600);

		/* 	GET password value*/
		key = KEYPAD_getPressedKey();

		pass[counter]=key;

		/* 	Display * in LCD every 	Entering a number */
		LCD_displayCharacter('*');
	}
	//pass[counter]='#';
	while(key != '=')
		key = KEYPAD_getPressedKey();


	/* Sending password element by element */
	UART_sendByte(MC1_READY);
	UART_sendByte(pass[0]);

	UART_sendByte(MC1_READY);
	UART_sendByte(pass[1]);

	UART_sendByte(MC1_READY);
	UART_sendByte(pass[2]);

	UART_sendByte(MC1_READY);
	UART_sendByte(pass[3]);

	UART_sendByte(MC1_READY);
	UART_sendByte(pass[4]);
}

