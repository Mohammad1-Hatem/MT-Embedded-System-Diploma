/*
 * HMI_Functions.h
 *
 *  Created on: Nov 6, 2022
 *      Author: mohatem
 */

#ifndef HMI_FUNCTIONS_H_
#define HMI_FUNCTIONS_H_

#include <avr/io.h>
#include <util/delay.h>
#include "LCD.h"
#include "keypad.h"
#include "UART.h"
#include "UART_communication.h"

/************************************************************************
  	  	  	  	  	  	  	 Function Prototypes
 ***********************************************************************/

/*
 * Description :
 * Ask the user for the password and confirmation ...
 * and if matched store it automatically at EEPROM.
 */
void Start_APP();

/*
 * Description :
 * It's responsible for the main options (open door - change password).
 */
void Main_APP();

/*
 * Description :
 * It's responsible for opening the door via controlling the motor.
 */
void Open_Door();

/*
 * Description :
 * It's responsible for initiating the buzzer if the user entered ...
 * wrong password for 3 times!
 */
void Wrong_Pass_Error();


/*
 * Description :
 * It's responsible for taking the passwords from the user element by element.
 */
void Enter_Pass(uint8 *pass);

void Recieve_Pass(uint8 *pass_ptr);

#endif /* HMI_FUNCTIONS_H_ */
