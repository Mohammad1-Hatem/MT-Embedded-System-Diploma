/*
 * Mini_Project2
 * Project2.c
 *
 *  Created on: Sep 22, 2022
 *      Author: Mohammad Hatem
 *      Diploma: 72
 */

#include<avr/io.h>
#include<util/delay.h>
#include<avr/interrupt.h>

#define time_delay 100    // Delay by 100 us

/* Declaration of global time variables (seconds - minutes - hours) */
unsigned char second_tick = 0;
unsigned char minutes_tick = 0;
unsigned char hours_tick = 0;

/* Interrupt Service Routine for timer1 compare mode */
ISR(TIMER1_COMPA_vect){
	second_tick ++; // Increase seconds while entering the ISR

	if(second_tick == 60){
		second_tick = 0;
		minutes_tick ++;
	}
	if(minutes_tick == 60){
		minutes_tick = 0;
		hours_tick ++;
	}
	if(hours_tick == 24){
		hours_tick = 0;
	}
}

/* Interrupt Service Routine for Interrupt 0 */
ISR(INT0_vect){

	/* Put zero in all global variables and Timer counter */
	second_tick = 0;
	minutes_tick = 0;
	hours_tick = 0;

	TCNT1 = 0;
}

/* Interrupt Service Routine for Interrupt 1 */
ISR(INT1_vect){
	/* Make the clock equal zero to stop the Timer */
	TCCR1B &=~ (1<<CS10) &~ (1<<CS12);
}

/* Interrupt Service Routine for Interrupt 2 */
ISR(INT2_vect){
	/* Redefine the clock to resume the Timer */
	TCCR1B |= (1<<CS10) | (1<<CS12);
}


/*
 F_CPU = 1 MHz
 N = 1024 >> Pre-scalar

 F_Timer = F_CPU / N = 1 (MHz) / 1024 ~= 976.5625 Hz
 T_Timer = 1 / F_Timer = 1.024 e-3 seconds
 Number of ticks in 1 second = 976.525 ~ 977 ticks
 OCR = 977
 */

/*Initializing the timer*/
void TIMER1_COMP_Init(void){

	TCNT1 = 0; /* Initializing the counter from 0 */

	OCR1A = 977; /* Set the Compare value to 977 */

	TIMSK = (1<<OCIE1A);  /* Enable Timer1 Compare A Interrupt */

	/* Configure timer control register TCCR1A
	 * 1. Disconnect OC1A and OC1B  COM1A1=0 COM1A0=0 COM1B0=0 COM1B1=0
	 * 2. FOC1A=1 FOC1B=0
	 * 3. CTC Mode WGM10=0 WGM11=0 (Mode Number 4)
	 */

	TCCR1A = (1<<FOC1A) | (1<<FOC1B); //For non PWM

	TCCR1B = (1<<WGM12) | (1<<CS10) | (1<<CS12); //For CTC mode and 1024 clock selection
}

/* Initializing INT0 to reset the Timer */
void INT0_Init(void){

	DDRD &=~ (1<<PD2);  /* Configure PD2 as input pin */
	PORTD |= (1<<PD2);  /* Set PD2 pin */

	MCUCR = (1<<ISC01);  /* Enable INT0 */

	GICR = (1<<INT0);  /* Enable bit of external INT >> INT0 */
}

/* Initializing INT1 to stop the Timer */
void INT1_Init(void){
	DDRD &=~ (1<<PD3);  /* Configure PD3 as input pin */
	PORTD |= (1<<PD3);  /* Set PD3 pin */

	MCUCR |= (1<<ISC10) | (1<<ISC11); /* Enable INT1 */

	GICR |= (1<<INT1);  /* Enable bit of external INT >> INT1 */
}


/* Initializing INT2 to resume the Timer */
void INT2_Init(void){
	DDRB &=~ (1<<PB2); /* Configure PB3 as input pin */
	PORTB |= (1<<PB2); /* Set PB3 pin */

	MCUCSR = 0; /* Enable INT2 */

	GICR |= (1<<INT2);  /* Enable bit of external INT >> INT2 */
}

int main(void){

	SREG = (1<<7); /*Enable global interrupts in MC*/

	/* Calling the functions */
	TIMER1_COMP_Init();
	INT0_Init();
	INT1_Init();
	INT2_Init();

	/*Pins of PORTA determines which 7-segment*/
	DDRA =  0x3F;  /* Configure first 5 pins of PORTA as output pins >> (0 - 5)*/
	PORTA = 0xFF; /* Initialize each 7-segment with value 1 by clear the first five bits in PORTA*/

	/*Pins of PORTA display data on each 7-segment*/
	DDRC = 0x0F; /*Configure first 4 pins of PORTC as output pins >> (0 - 4)*/
	PORTC = 0; /*Initialize the 7-segment with value 1 by clear the first four bits in PORTC*/


	_delay_us(time_delay);

	for(;;){

		/* Display on 7-segments */

		PORTA = (1<<PA0); //Enable 1st 7-segment
		PORTC = (PORTC & 0xF0) | ((second_tick%10) & 0x0F); //Display the single digits of seconds from (0 - 9) on the 1st 7-segment
		_delay_us(time_delay); //Delay with 100 us

		PORTA = (1<<PA1); //Enable 1st 7-segment
		PORTC = (PORTC & 0xF0) | ((second_tick/10) & 0x0F); //Display the tens place of seconds from (0 - 5) on the 2nd 7-segment
		_delay_us(time_delay); //Delay with 100 us

		PORTA = (1<<PA2); //Enable 1st 7-segment
		PORTC = (PORTC & 0xF0) | (minutes_tick%10 & 0x0F); //Display the single digits of minutes from (0 - 9) on the 3rd 7-segment
		_delay_us(time_delay); //Delay with 100 us

		PORTA = (1<<PA3); //Enable 1st 7-segment
		PORTC = (PORTC & 0xF0) | (minutes_tick/10 & 0x0F); //Display the tens place of minutes from (0 - 5) on the 4th 7-segment
		_delay_us(time_delay); //Delay with 100 us

		PORTA = (1<<PA4); //Enable 1st 7-segment
		PORTC = (PORTC & 0xF0) | (hours_tick%10 & 0x0F); //Display the single digits of hours from (0 - 9) on the 5th 7-segment
		_delay_us(time_delay); //Delay with 100 us

		PORTA = (1<<PA5); //Enable 1st 7-segment
		PORTC = (PORTC & 0xF0) | (hours_tick/10 & 0x0F); //Display the tens place of hours from (0 - 5) on the 6th 7-segment
		_delay_us(time_delay); //Delay with 100 us

	} /* End the loop */

} /*End main*/

