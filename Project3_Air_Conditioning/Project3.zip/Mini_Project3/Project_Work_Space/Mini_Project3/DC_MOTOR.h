/*
 * DC_MOTOR.h
 *
 *  Created on: Oct 11, 2022
 *      Author: mohatem
 */

#ifndef DC_MOTOR_H_
#define DC_MOTOR_H_

#include "std_types.h"

/*******************************************************************************
 *                              Definition                                  *
 *******************************************************************************/

/* Motor pins */
#define ENABLE_MOTOR_PORT_ID                      PORTB_ID
#define ENABLE_MOTOR_PIN_ID                       PIN3_ID

#define INPUT1_PORT_ID                            PORTB_ID
#define INPUT1_PIN_ID                             PIN0_ID

#define INPUT2_PORT_ID                            PORTB_ID
#define INPUT2_PIN_ID                             PIN1_ID


/*******************************************************************************
 *                         Types Declaration                                   *
 *******************************************************************************/

/* Description
 * Declare the modes of the motor (Clockwise - Counter Clockwise - stop)
 * */
typedef enum{
	rotate_CW,rotate_CCW,stop
}DcMotor_State;

/******************************************************************************************
 *                                  Functions Prototypes
 ******************************************************************************************/

/*
 * Description :
 * Function responsible for initialize the DcMotor driver.
 */
void DcMotor_Init(void);

/*
 * Description :
 * Function responsible for setting pins out to the H-Bridge,
 * and setting motor state (rotate CW/CCW - stop).
 */
void DcMotor_Rotate(DcMotor_State state,uint8 speed);

#endif /* DC_MOTOR_H_ */
