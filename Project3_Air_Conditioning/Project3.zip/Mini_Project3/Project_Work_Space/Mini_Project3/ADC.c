/*
 * ADC.c
 *
 *  Created on: Oct 6, 2022
 *      Author: mohatem
 */

#include "ADC.h"
#include "Common_macros.h"
#include <avr/io.h>

/*******************************************************************************
 *                      Functions Definitions                                  *
 *******************************************************************************/

void ADC_init(const ADC_ConfigType * Config_Ptr){
	/* ADMUX Register Bits Description:
	 * REFS1:0 = 01 to choose AVCC = 5v as reference voltage
	 * ADLAR   = 0 right adjusted
	 * MUX4:0  = 00000 to choose channel 0 as initialization
	 */
	ADMUX = (ADMUX & 0x00) | ((Config_Ptr->ref_volt)<<6);
	ADCSRA |= (1<<ADEN);
	ADCSRA = (ADCSRA & 0xF8) | (Config_Ptr->prescaler);

}

uint16 ADC_readChannel(uint8 ch_num){

	ADMUX = (ADMUX & 0b11100000) | (ch_num & 0b00000111);
	SET_BIT(ADCSRA,ADSC); /* Start ADC Conversion*/
	while(BIT_IS_SET(ADCSRA,ADIF)); /* Polling */
	SET_BIT(ADCSRA,ADIF); /* Clear interrupt flag */

	return ADC;

}
