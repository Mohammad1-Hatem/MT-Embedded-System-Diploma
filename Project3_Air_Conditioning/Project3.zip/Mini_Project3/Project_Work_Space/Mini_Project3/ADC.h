/*
 * ADC.h
 *
 *  Created on: Oct 6, 2022
 *      Author: mohatem
 */

#ifndef ADC_H_
#define ADC_H_

#include "std_types.h"

/*******************************************************************************
 *                                Definitions                                  *
 *******************************************************************************/
#define ADC_MAXIMUM_VALUE    1023
#define ADC_REF_VOLT_VALUE   2.56

typedef enum
{
	F_CPU_2 = 1, F_CPU_4 = 2, F_CPU_8 = 3, F_CPU_16 = 4,F_CPU_32 = 5
}ADC_Prescaler;

typedef enum
{
	AREF, AVCC, RSERVED,INTERNAL
}ADC_ReferenceVolatge;

typedef struct
{
	ADC_Prescaler prescaler;
	ADC_ReferenceVolatge ref_volt;

}ADC_ConfigType;

/*******************************************************************************
 *                      Functions Prototypes                                   *
 *******************************************************************************/

void ADC_init(const ADC_ConfigType * Config_Ptr);

uint16 ADC_readChannel(uint8 ch_num);

#endif /* ADC_H_ */
