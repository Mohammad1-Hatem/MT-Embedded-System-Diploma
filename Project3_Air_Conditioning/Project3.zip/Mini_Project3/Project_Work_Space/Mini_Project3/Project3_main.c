/*
 * Mini_Project3
 * Project3_main.c
 *
 *  Created on: Oct 13, 2022
 *      Author: Mohammad Hatem
 *      Diploma: 72
 */

#include <avr/io.h>
#include "PWM.h"
#include "DC_MOTOR.h"
#include <util/delay.h>
#include "LCD.h"
#include "ADC.h"
#include "lm35_sensor.h"

int main(void){

	uint8 temperature;

	LCD_init(); /* Initialize the LCD */

	/* Display this string "Fan is " only once on LCD at the first row */
	LCD_displayStringRowColumn(0,3,"Fan is ");

	/* Display this string "Temp =   C" only once on LCD at the second row */
	LCD_displayStringRowColumn(1,3,"Temp =    C");

	/* Create configuration structure for ADC driver */
	ADC_ConfigType ADC_Config = {F_CPU_8,INTERNAL};

	DcMotor_Init(); /* Initialize the DcMotor */

	ADC_init(&ADC_Config); /* Initialize the ADC */

	for(;;){

		temperature = LM35_getTemperature();

		/* Display the temperature value every time at same position */
		LCD_moveCursor(1,10);

		LCD_intgerToString(temperature);

		if(temperature < 30){

			LCD_displayStringRowColumn(0,11,"OFF");
			DcMotor_Rotate(stop,0);
		}

		else if(temperature >= 30 && temperature < 60){
			LCD_displayStringRowColumn(0,11,"ON ");
			DcMotor_Rotate(rotate_CW,Quarter_duty_cycle);
		}

		else if(temperature >= 60 && temperature < 90){
			LCD_displayStringRowColumn(0,11,"ON ");
			DcMotor_Rotate(rotate_CW,Half_duty_cycle);
		}

		else if(temperature >= 90 && temperature < 120){
			LCD_displayStringRowColumn(0,11,"ON ");
			DcMotor_Rotate(rotate_CW,Three_Quarters_duty_cycle);
		}

		else if(temperature >= 120){
			LCD_displayStringRowColumn(0,11,"ON ");
			DcMotor_Rotate(rotate_CW,Full_duty_cycle);
		}
	}
}
